<?php $__env->startSection('content'); ?>

<h2 style="color: green;text-align: center;"> <b>Stock List</h2>
<table class="table table-hover" style="margin:10px">
    <thead style="background-color:white">
       
    </thead>
<tbody>

     <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
 
       <td>

         <h6 style="color: blue">Token:<?php echo e($orders->token->name); ?></h6>
         <h6 style="color: blue">Name:<?php echo e($orders->cname); ?></h6>
       <h6 style="color: red">phone:<?php echo e($orders->cphone); ?></h6>
        <h6 style="color: green">Advance:<?php echo e($orders->advance); ?></h6>
       <p style="color: brown">Date:<small><?php echo e($orders->date); ?></small></p>
       <br>
            
            </td>

<td> <a href="" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-remove"></i> Delete</a></td>
<td><a href="<?php echo e(route('getstore.invoice',$orders->id)); ?>" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-wrench"></i> invoice</a>
</td>
 
       <tr>
           
             <th>id</th>
               <th>Product Name</th>
               <th>Product Quantity</th>
               <th>Product Size</th> 
               <th>Color</th>
               <th>Serial Number</th>
              
              <th>Shift to Cleaning</th>
                  <th>Status Coating</th>
                 <th>Status Finish</th>
           
                        <?php if(Auth::User()->hasrole('admin')): ?>
                
                <th>Action</th>
               <?php endif; ?>
                
          
        </tr>

           <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

<?php if($cls->customer_id==$orders->id): ?>

            <tr>
                <td><?php echo e($cls->id); ?></td>
                <td><?php echo e($cls->product->name); ?></td>
                <td><?php echo e($cls->pquantity); ?></td>
                <td><?php echo e($cls->size->name); ?></td>
                
              <td><?php echo e($cls->color->name); ?></td>
                <td><?php echo e($cls->serial->name); ?></td>
             
              <?php if($cls->status_cleaning==null): ?>
               <td><input type="checkbox" name="shiftcleaning" value="<?php echo e($cls->id); ?>"></td>
               <?php else: ?>
               <td>sent to cleaning</td>
<?php endif; ?>

              <?php if($cls->status_coating==null): ?>
<td><h6 style="color: red">Not  in coating</h6></td>
<?php else: ?>

<td><h6 style="color: green"> Shifted in coating</h6></td>
              
               <?php endif; ?>
              <?php if($cls->status_coating==null): ?>
<td><h6 style="color: red"> Not finished</h6></td>
<?php else: ?>

<td><h6 style="color: green"> Finished</h6></td>
           <?php endif; ?>





                        <?php if(Auth::User()->hasrole('admin')): ?>
        
      
<td>
                <a href="" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-remove"></i> Delete</a>
                
             
               </td>
              <?php endif; ?>
            </tr>
            <?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
               
            

        


<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </tbody>
    
  
</table>
<script type="text/javascript">
  
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<script type="text/javascript">

function printContent(el){

var restorpage=document.body.innerHTML;
var printcontent=document.getElementById(el).innerHTML;

document.body.innerHTML=printcontent;
window.print();
document.body.innerHTML=restorpage;
window.close();
}
$('#saveOffer').click(function () {
  window.history.pushState('forward', null, '/');
  setTimeout(function () {
    window.location.reload();
},1000);
});

</script>
<script type="text/javascript" src="<?php echo e(asset('js/Stock/update.js')); ?>"></script>

<script type="text/javascript">
var token='<?php echo e(Session::token()); ?>';
var add='<?php echo e(route('shift.cleaning')); ?>';

</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>