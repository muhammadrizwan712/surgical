


<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title> Invoice</title>
  <link rel="stylesheet" href="{{asset('dashboard/css/bootstrap2.css')}}">
  <style>
  @import url(http://fonts.googleapis.com/css?family=Bree+Serif);
  body, h1, h2, h3, h4, h5, h6{
    font-family: 'Bree Serif', serif;
  }
  </style>
</head>
<body>
  <div class="row">
      
      <div class="col-md-12">
       <div class="span7">
        <div class="panel panel-info">
          <div class="panel-heading">
           <button class="btn btn-primary pull-right " onclick="printContent('divide')">print</button>

           
            <a href="/home"><button class="btn btn-danger ">Home</button></a>
          </div>
         
        </div>
      </div>
      </div>
    </div>
<div id="divide">
  

  <div class="container" >

  
    

   <!-- / end client details section -->

             <table class="table table-bordered">
        <thead>
          <tr>
            
            <th><h4>Customer Name</h4></th>
            <th><h4>Customer Phone</h4></th>
            <th><h4>GP Number</h4></th>
           
            <th><h4>Due Amount</h4></th>
          

          
          </tr>
        </thead>
        <tbody>
             @if($users!=null)
         @foreach($users as $in)
         @if($in->due !=null)
          <tr>
       
           <td class="service">{{$in->cname}}</td>
            <td class="desc">{{$in->cphone}}</td>
           <td class="desc">{{$in->rnumber}}</td>
            <td class="desc">{{$in->due}}</td>
            
         
           
            
          </tr>
        @endif
          @endforeach
            @endif
       
        </tbody>
      </table>

   
</div>
</div>


</body>
<script type="text/javascript">

function printContent(el){

var restorpage=document.body.innerHTML;
var printcontent=document.getElementById(el).innerHTML;

document.body.innerHTML=printcontent;
window.print();
document.body.innerHTML=restorpage;
window.close();
}
$('#saveOffer').click(function () {
  window.history.pushState('forward', null, '/');
  setTimeout(function () {
    window.location.reload();
},1000);
});

</script>

</html>
