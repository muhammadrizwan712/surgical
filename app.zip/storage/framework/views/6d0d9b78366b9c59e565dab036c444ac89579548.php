<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		

		  <div style="background-color: white">
    <br><br>
  
  <h2 style="text-align: center;color:  blue">Due List</h2>


<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
              <th>Customer Name</th>
              <td>Customer Phone</td>
                <th>Total</th>
                <th>Advance</th>

                <th>Recieve</th>
                       <th>Due</th>
                       <td>Date</td>
               
               
                
            </tr>
        </thead>
       
        <tbody>
          <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>

                
                <td><?php echo e($cls->customer->cname); ?></td>
                <td><?php echo e($cls->customer->cphone); ?></td>
                <td><?php echo e($cls->total); ?></td>
                <td><?php echo e($cls->advance); ?></td>
                <td><?php echo e($cls->recieve); ?></td>
                <td><?php echo e($cls->balance); ?></td>
                <td><?php echo e($cls->date); ?></td>
                <td><a href="<?php echo e(route('recieve.it',$cls->id)); ?>"><button class="btn btn-success">Recieve</button></a></td>
                       

            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>

<script type="text/javascript">
  
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script>


</div>
	</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard/dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>