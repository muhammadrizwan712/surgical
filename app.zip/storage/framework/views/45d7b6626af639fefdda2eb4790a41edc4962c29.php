<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		

		  <div style="background-color: white">
    <br><br>
  
  <h2 style="text-align: center;color:  blue">Payment Detail</h2>


<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
              <th>Invoice id</th>
              <th>Recieve</th>
                <th>Date</th>
                
               
                
            </tr>
        </thead>
       
        <tbody>
          <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>

                <td><?php echo e($cls->invoice_id); ?></td>
                <td><?php echo e($cls->recieve); ?></td>
                <td><?php echo e($cls->created_at); ?></td>
                
               
                       

            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>

<script type="text/javascript">
  
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<script type="text/javascript" src="<?php echo e(asset('js/Color/update.js')); ?>"></script>
<script type="text/javascript">
var token='<?php echo e(Session::token()); ?>';
var add='<?php echo e(route('edit.size')); ?>';

</script> 
</div>
	</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard/dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>