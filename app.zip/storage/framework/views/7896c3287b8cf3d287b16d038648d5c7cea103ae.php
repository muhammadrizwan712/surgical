
<!DOCTYPE HTML>
<html>
<head>
<title>dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="school system " />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="<?php echo e(asset('dashboard/css/bootstrap.min.css')); ?>" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="<?php echo e(asset('dashboard/css/style.css')); ?>" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="<?php echo e(asset('dashboard/css/lines.css')); ?>" rel='stylesheet' type='text/css' />
<link href="<?php echo e(asset('dashboard/css/font-awesome.css')); ?>" rel="stylesheet"> 
<!-- jQuery -->
<script src="<?php echo e(asset('dashboard/js/jquery.min.js')); ?>"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Nav CSS -->
<link href="<?php echo e(asset('dashboard/css/custom.css')); ?>" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo e(asset('dashboard/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/custom.js')); ?>"></script>
<!-- Graph JavaScript -->
<script src="<?php echo e(asset('dashboard/js/d3.v3.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/js/rickshaw.js')); ?>"></script>
 <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">


</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
        <nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/"><?php echo e(Auth::user()->name); ?></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-comments-o"></i><span class="badge">4</span></a>
              <ul class="dropdown-menu">
            <li class="dropdown-menu-header">
              <strong>Messages</strong>
              <div class="progress thin">
                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                  <span class="sr-only">40% Complete (success)</span>
                </div>
              </div>
            </li>
           
           
           
            
           
            
            <li class="dropdown-menu-footer text-center">
              <a href="#">View all messages</a>
            </li> 
              </ul>
            </li>
          <li class="dropdown">
              <a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"><img src="<?php echo e(asset('dashboard/images/1.png')); ?>"><span class="badge">9</span></a>
              <ul class="dropdown-menu">
          
             <li class="dropdown">
                                

                                
                                    <li  class="m_2">
                                        <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                               
                            </li>

              </ul>
            </li>
      </ul>
      <form class="navbar-form navbar-right">
              <input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
            </form>
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="#"><i class="fa fa-dashboard fa-fw nav_icon"></i>Dashboard</a>
                        </li>

 
                        <?php if(Auth::User()->hasrole('cleaning')): ?>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Stocks<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                               
                                <li>
                                    <a href="<?php echo e(route('get.clean')); ?>">View Clean Stock</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('get.unclean')); ?>">View Unclean Stock</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         
                        <?php endif; ?>
                        <?php if(Auth::User()->hasrole('coating')): ?>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Stocks<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                               
                                <li>
                                    <a href="<?php echo e(route('get.coat')); ?>">View coated Stock</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('get.uncoat')); ?>">View Uncoated Stock</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         
                        <?php endif; ?>
                   
                        <?php if(Auth::User()->hasrole('admin')): ?>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Stocks<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.stock')); ?>">Entry Stock</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('view.stock')); ?>">View Stock</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                           <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Product Price<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('get.product')); ?>">Add Items</a>
                                </li>
                               <li>
                                    <a href="<?php echo e(route('get.size')); ?>">Add Size</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('get.product.price')); ?>">Set Price</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Report Generate<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('get.customer.invoice')); ?>">Customer Report</a>
                                </li>
                               <li>
                                    <a href="<?php echo e(route('summery.report')); ?>">Summery Report</a>
                                </li>
                                
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         
                          <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Color<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.color')); ?>">Color Management</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Token<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.token')); ?>">Token Management</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

<li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Location <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.serial')); ?>">Location Management</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li> 
                        <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Payment Managment <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('due.list')); ?>">Due List</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('get.customer')); ?>">Credit Customer</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>  
                                              <?php endif; ?>
                       
                        <?php if(Auth::User()->hasrole('entry')): ?>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Stocks<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.stock')); ?>">Entry Stock</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('view.stock')); ?>">View Stock</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                           <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Product Price<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('get.product')); ?>">Add Items</a>
                                </li>
                               <li>
                                    <a href="<?php echo e(route('get.size')); ?>">Add Size</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('get.product.price')); ?>">Set Price</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Report Generate<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('get.customer.invoice')); ?>">Customer Report</a>
                                </li>
                               <li>
                                    <a href="<?php echo e(route('summery.report')); ?>">Summery Report</a>
                                </li>
                                
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         
                          <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Color<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.color')); ?>">Color Management</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Token<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.token')); ?>">Token Management</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

<li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Location <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('create.serial')); ?>">Location Management</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li> 
                        <li>
                            <a href="#"><i class="fa fa-laptop nav_icon"></i>Payment Managment <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('due.list')); ?>">Due List</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('get.customer')); ?>">Credit Customer</a>
                                </li>
                               
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>  
                                              <?php endif; ?>
                       
  
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
    
        </nav>
        <div id="page-wrapper">
      


<?php echo $__env->yieldContent('content'); ?>
    
  
   
    
    </div>
 
       </div>
 

      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
    <!-- Bootstrap Core JavaScript -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/clndr.css')); ?>" type="text/css" />
            <script src="<?php echo e(asset('dashboard/js/underscore-min.js')); ?>" type="text/javascript"></script>
            <script src= "<?php echo e(asset('dashboard/js/moment-2.2.1.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('dashboard/js/clndr.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('dashboard/js/site.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('dashboard/js/bootstrap.min.js')); ?>"></script>
     <script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
</body>
</html>
