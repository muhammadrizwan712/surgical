<?php $__env->startSection('content'); ?>
<?php echo $__env->make('message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form method="post" action="<?php echo e(route('post.customer.invoice')); ?>">
	
<?php echo e(csrf_field()); ?>

<div class="col-md-12">
	<center><h3>Customer Invoices</h3></center>
	<div class="col-md-3">
		<select name="customer" class="form-control">
			<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<option value="<?php echo e($cus->id); ?>" name="customer"> 
				<?php echo e($cus->cname); ?>

			</option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</select>
	</div>
	<div class="col-md-3">
		<input type="date" name="fromdate">
	</div>
	<div class="col-md-3">
		<input type="date" name="todate">
	</div>
	<div class="col-md-3">
		<button class="btn btn-primary">Report</button>
	</div>
	
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>